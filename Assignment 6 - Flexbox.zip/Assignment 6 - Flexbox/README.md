Flexbox Assignment

Clone this page: https://www.instagram.com/google

